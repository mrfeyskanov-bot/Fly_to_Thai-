<?php
/**
 * Настройки темы
 * 
 * @package Fly_to_Thai
 * @since 1.0.0
 */

/**
 * Регистрация кастомизаций
 */
function flytothai_customize_register( $wp_customize ) {
    // Панель контактов
    $wp_customize->add_section( 'flytothai_contacts', array(
        'title'    => __( 'Контакты', 'fly-to-thai' ),
        'priority' => 30,
    ) );
    
    // Телефон
    $wp_customize->add_setting( 'flytothai_phone', array(
        'default'           => '+7 (951) 816-74-44',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    
    $wp_customize->add_control( 'flytothai_phone', array(
        'label'    => __( 'Телефон', 'fly-to-thai' ),
        'section'  => 'flytothai_contacts',
        'type'     => 'text',
    ) );
    
    // Email
    $wp_customize->add_setting( 'flytothai_email', array(
        'default'           => 'info@flytothai.ru',
        'sanitize_callback' => 'sanitize_email',
    ) );
    
    $wp_customize->add_control( 'flytothai_email', array(
        'label'    => __( 'Email', 'fly-to-thai' ),
        'section'  => 'flytothai_contacts',
        'type'     => 'email',
    ) );
    
    // Адрес
    $wp_customize->add_setting( 'flytothai_address', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    
    $wp_customize->add_control( 'flytothai_address', array(
        'label'    => __( 'Адрес', 'fly-to-thai' ),
        'section'  => 'flytothai_contacts',
        'type'     => 'text',
    ) );
    
    // Соцсети
    $wp_customize->add_section( 'flytothai_social', array(
        'title'    => __( 'Социальные сети', 'fly-to-thai' ),
        'priority' => 31,
    ) );
    
    // VK
    $wp_customize->add_setting( 'flytothai_vk', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ) );
    
    $wp_customize->add_control( 'flytothai_vk', array(
        'label'    => __( 'VKontakte', 'fly-to-thai' ),
        'section'  => 'flytothai_social',
        'type'     => 'url',
    ) );
    
    // Instagram
    $wp_customize->add_setting( 'flytothai_instagram', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ) );
    
    $wp_customize->add_control( 'flytothai_instagram', array(
        'label'    => __( 'Instagram', 'fly-to-thai' ),
        'section'  => 'flytothai_social',
        'type'     => 'url',
    ) );
    
    // Telegram
    $wp_customize->add_setting( 'flytothai_telegram', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ) );
    
    $wp_customize->add_control( 'flytothai_telegram', array(
        'label'    => __( 'Telegram', 'fly-to-thai' ),
        'section'  => 'flytothai_social',
        'type'     => 'url',
    ) );
}

add_action( 'customize_register', 'flytothai_customize_register' );

/**
 * Вспомогательные классы
 */
if ( class_exists( 'Walker_Nav_Menu' ) ) {
    class Bootstrap_Navbar_Walker extends Walker_Nav_Menu {
        public function start_el( &$output, $item, $depth = 0, $args = NULL, $id = 0 ) {
            if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
                $t = '';
                $n = '';
            } else {
                $t = "\t";
                $n = "\n";
            }
            $indent = ( $depth ) ? str_repeat( $t, $depth ) : '';
            $output .= $indent . '<li class="nav-item' . ( $depth > 0 ? ' dropdown-item' : '' ) . '">';
            
            $atts = array();
            $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
            $atts['target'] = ! empty( $item->target ) ? $item->target : '';
            $atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
            $atts['href']   = ! empty( $item->url ) ? $item->url : '';
            
            if ( in_array( 'current-menu-item', $item->classes, true ) ) {
                $atts['class'] = 'nav-link active';
            } else {
                $atts['class'] = 'nav-link';
            }
            
            if ( $item->menu_item_parent != 0 ) {
                $atts['class'] .= ' dropdown-item';
            }
            
            $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );
            
            $attributes = '';
            foreach ( $atts as $attr => $value ) {
                if ( ! empty( $value ) ) {
                    $value      = 'href' === $attr ? esc_url( $value ) : esc_attr( $value );
                    $attributes .= ' ' . $attr . '="' . $value . '"';
                }
            }
            
            $title = apply_filters( 'nav_menu_item_title', $item->title, $item, $args, $depth );
            $title = apply_filters( 'nav_menu_item_custom_title', $title, $item, $args, $depth );
            
            $output .= '<a' . $attributes . '>';
            $output .= $title;
            $output .= '</a>';
        }
    }
}
