<?php
/**
 * Подключение и регистрация скриптов и стилей
 * 
 * @package Fly_to_Thai
 * @since 1.0.0
 */

function flytothai_enqueue_scripts() {
    // Bootstrap CSS
    wp_enqueue_style( 
        'bootstrap-css',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
        array(),
        '5.3.0'
    );
    
    // Google Fonts
    wp_enqueue_style(
        'google-fonts',
        'https://fonts.googleapis.com/css2?family=Varta:wght@300;400;500;600;700&family=Vollkorn+SC:wght@400;600;700&display=swap',
        array(),
        '1.0'
    );
    
    // Font Awesome
    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
        array(),
        '6.4.0'
    );
    
    // Основной стиль темы
    wp_enqueue_style(
        'flytothai-style',
        FLYTOTHAI_URI . '/styles/custom.css',
        array( 'bootstrap-css', 'google-fonts', 'font-awesome' ),
        FLYTOTHAI_VERSION
    );
    
    // Анимации
    wp_enqueue_style(
        'flytothai-animations',
        FLYTOTHAI_URI . '/styles/animations.css',
        array( 'flytothai-style' ),
        FLYTOTHAI_VERSION
    );
    
    // Bootstrap JS
    wp_enqueue_script(
        'bootstrap-js',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
        array(),
        '5.3.0',
        true
    );
    
    // Главный скрипт
    wp_enqueue_script(
        'flytothai-main',
        FLYTOTHAI_URI . '/js/main.js',
        array( 'jquery', 'bootstrap-js' ),
        FLYTOTHAI_VERSION,
        true
    );
    
    // Валидация формы
    wp_enqueue_script(
        'flytothai-form-validation',
        FLYTOTHAI_URI . '/js/form-validation.js',
        array( 'jquery' ),
        FLYTOTHAI_VERSION,
        true
    );
    
    // Анимации
    wp_enqueue_script(
        'flytothai-animations',
        FLYTOTHAI_URI . '/js/animations.js',
        array(),
        FLYTOTHAI_VERSION,
        true
    );
    
    // Передать данные в JS
    wp_localize_script( 'flytothai-main', 'flyToThaiData', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'flytothai-nonce' ),
    ) );
    
    // Поддержка встроенных комментариев
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}

add_action( 'wp_enqueue_scripts', 'flytothai_enqueue_scripts' );

/**
 * Подключить стили админпанели
 */
function flytothai_enqueue_admin_scripts() {
    wp_enqueue_style(
        'flytothai-admin',
        FLYTOTHAI_URI . '/css/admin.css',
        array(),
        FLYTOTHAI_VERSION
    );
}

add_action( 'admin_enqueue_scripts', 'flytothai_enqueue_admin_scripts' );
